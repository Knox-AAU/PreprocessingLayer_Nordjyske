from io import StringIO

import pytest

from knox_source_data_io.IOHandler import *
from knox_source_data_io.models.article import Article


class TestIOHandler:
    handler: IOHandler

    def setup_method(self, method):
        self.handler = IOHandler(Generator(app="This app", version=1.0), None)

    def test_write_json_returns_valid_json(self):
        content_obj = Article()

        # Create StringIO object to store the output of the method
        outfile = StringIO()

        # Call method
        self.handler.write_json(content_obj, outfile)

        # Read the output
        outfile.seek(0)
        output_content = outfile.read()

        try:
            # Check to see if the output can parsed as JSON
            json.loads(output_content)
        except ValueError:
            pytest.fail("Generated string is not valid JSON")

        assert True

    def test_read_json_fails_due_to_file_not_existing(self):
        try:
            with open("/this/path/does/not/exist/and/will/cause/the/test/to/fail", 'r') as json_file:
                self.handler.read_json(json_file)
            assert False
        except OSError as e:
            assert True

    def test_convert_to_dict(self):
        assert False

    def test_dict_to_obj(self):
        assert False
#response = requests.get("https://knox.libdom.net/schema/article.schema.json")
#schema = response.json()